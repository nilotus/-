package com.jit.sensor.service;

import com.jit.sensor.mapper.RelaybinduserMapper;
import com.jit.sensor.entity.RelaybinduserKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RelaybinduserService {
    @Autowired
    RelaybinduserMapper relaybinduserMapper;

    public boolean insert(RelaybinduserKey r){
        return relaybinduserMapper.insert(r)>0;
    }

    public RelaybinduserKey selectByBindata(String deveui,String userid){
        return  relaybinduserMapper.selectBindData(deveui,userid);
    }

    public List<RelaybinduserKey> selectall(){
        return  relaybinduserMapper.selectall();
    }
}
