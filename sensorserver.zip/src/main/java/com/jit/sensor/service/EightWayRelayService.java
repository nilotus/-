package com.jit.sensor.service;

import com.jit.sensor.mapper.EightwayrelayMapper;
import com.jit.sensor.entity.Eightwayrelay;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EightWayRelayService {
    @Autowired
    EightwayrelayMapper eightwayrelayMapper;

    public boolean insert(Eightwayrelay e){
        return  eightwayrelayMapper.insert(e)>0;
    }
    public Eightwayrelay select(String deveui){
        return  eightwayrelayMapper.selectByPrimaryKey(deveui);
    }
}
