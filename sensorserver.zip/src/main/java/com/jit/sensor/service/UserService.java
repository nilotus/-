package com.jit.sensor.service;

import com.jit.sensor.mapper.UserMapper;
import com.jit.sensor.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    UserMapper userMapper;

    public User findByUsername(String username) {
        return  userMapper.selectByUserName(username);
    }

    public User findById(int id) {
        return  userMapper.selectByPrimaryKey(id);
    }

    public boolean insert(User user){
        return  userMapper.insert(user)>0;
    }

    public boolean updateByUserName(User user){
        return  userMapper.updateByUserName(user)>0;
    }
}
