package com.jit.sensor.service;

import com.jit.sensor.mapper.RelayoperationMapper;
import com.jit.sensor.entity.Relayoperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RelayOperationService {
    @Autowired
    RelayoperationMapper relayoperationMapper;

    public boolean insert(Relayoperation r){
        return  relayoperationMapper.insert(r)>0;
    }



}
