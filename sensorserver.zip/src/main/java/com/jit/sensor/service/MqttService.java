package com.jit.sensor.service;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jit.sensor.global.MqttClient;
import com.jit.sensor.util.MqttConfig;
import com.jit.sensor.util.ReturnUtil;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.entity.TResultCode;
import com.jit.sensor.entity.User;
import org.fusesource.mqtt.client.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.jit.sensor.util.CRC.CRCcheck;


/**
 * @author chy
 */
@Service
public class MqttService {
    @Autowired
    EightWayRelayService eightWayRelayService;
    @Autowired
    RelayOperationService relayOperationService;
    @Autowired
    StringRedisTemplate redis;
    private int maxRecycleTime = 5;
    private int clientIdOffset = 1;

    /**
     * 添加订阅
     */
    public TMessage addSubscription(JSONObject jsonObject) {
        String recvTopic = "application/2" +
                "/device/" + jsonObject.getString("deveui") +
                "/rx";
        CallbackConnection callbackConnection = MqttClient.callbackConnection;
        /*
         * 订阅频道
         * */
        Set<Topic> topicSet;

        if (MqttClient.topics != null) {
            topicSet = new HashSet<>(Arrays.asList(MqttClient.topics));
        } else {
            topicSet = new HashSet<>();
        }
        topicSet.add(new Topic(recvTopic, QoS.EXACTLY_ONCE));
        Topic[] newTopics = topicSet.toArray(new Topic[topicSet.size()]);

        if (Arrays.equals(newTopics, MqttClient.topics)) {
            return ReturnUtil.finalObject(0, TResultCode.SUBSCRIPTION_EXISTS.getMessage(), new JSONObject());
        } else {
            callbackConnection.subscribe(newTopics,
                    new Callback<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            MqttClient.topics = topicSet.toArray(new Topic[topicSet.size()]);
                        }

                        @Override
                        public void onFailure(Throwable throwable) {
                        }
                    });
            return ReturnUtil.finalObject(1, TResultCode.SUCCESS.getMessage(), new JSONObject());
        }
    }


    /**
     * 设置传感器上传周期
     */
    public TMessage updateSensorCycle(JSONObject jsonObject) throws Exception {
        publishMqttMessage(jsonObject);
        Boolean result = getAckResult(jsonObject);
        if (result == null) {
            return ReturnUtil.finalObject(0, "超时", new JSONObject());
        }
        if (result) {
            return ReturnUtil.finalObject(1, "成功", new JSONObject());
        } else {
            return ReturnUtil.finalObject(0, "设置失败", new JSONObject());
        }
    }

    /**
     * 继电器八路状态读取
     */
    public TMessage getRelayStatus() throws Exception {
        /*
         * 向任意传感器发送功能码为02的指令即可获取八路继电器状态
         * 指令数据区数据区无意义
         * */
        LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<>();
        //暂时写死
        linkedHashMap.put("deveui", "004a770066003289");
        linkedHashMap.put("reference", "abcd1234");
        linkedHashMap.put("confirmed", true);
        linkedHashMap.put("fPort", 10);
        linkedHashMap.put("message", "02 00 00 D0 00");
        JSONObject jsonObject = new JSONObject();
        jsonObject.putAll(linkedHashMap);

        publishMqttMessage(jsonObject);
        byte[] decodedAckData = getAckData(jsonObject);
        if (decodedAckData == null) {
            return ReturnUtil.finalObject(0, "获取超时", new JSONObject());
        }
        if (decodedAckData[0] == 0x03) {
            /*
             * CRC校验
             * */
            if (CRCcheck(decodedAckData)) {
                String switchString = Integer.toBinaryString((decodedAckData[3] & 0xFF) + 0x100).substring(1);
                JSONObject j = new JSONObject();
                j.put("switchString", switchString);
                return ReturnUtil.finalObject(1, "获取成功", j);
            } else {
                return ReturnUtil.finalObject(0, "CRC校验失败", new JSONObject());
            }
        } else {
            /*
             * 数据非空且非0x03，异常数据
             * */
            return ReturnUtil.finalObject(0, "ack数据异常", new JSONObject());
        }
    }

    /**
     * 设置继电器开关
     */
    public TMessage setRelayStatus(JSONObject jsonObject, User usr) throws Exception {
        String[] datas = jsonObject.getString("message").split(" ");
        String key = jsonObject.getString("deveui") + "-3-" + Integer.valueOf(datas[1]);
        String value = redis.boundValueOps(key).get();
        if (value != null && ("1".equals(value) ? "FF" : "00").equals(datas[2])) {
            return ReturnUtil.finalObject(1, "该开关已为当前状态", new JSONObject());
        }

        publishMqttMessage(jsonObject);
        Boolean result = getAckResult(jsonObject);
        if (result == null) {
            return ReturnUtil.finalObject(0, "获取超时", new JSONObject());
        }
        // 数据下发成功
        if (result) {
            redis.boundValueOps(key).set(("00".equals(datas[2]) ? "0" : "1"));
            return ReturnUtil.finalObject(1, "设置成功", new JSONObject());
        } else {
            return ReturnUtil.finalObject(0, "设置失败", new JSONObject());
        }
    }

    /**
     * mqtt发送
     */
    private void publishMqttMessage(JSONObject jsonObject) throws URISyntaxException {
        String sendTopic = "application/2/device/" +
                jsonObject.getString("deveui") +
                "/tx";
        LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
        String messageKey = "message";
        boolean isFinished = false;

        linkedHashMap.put("reference", jsonObject.getString("reference"));
        linkedHashMap.put("confirmed", jsonObject.get("confirmed"));
        linkedHashMap.put("fPort", jsonObject.get("fPort"));

        Base64.Encoder encoder = Base64.getEncoder();
        String[] datas = jsonObject.getString(messageKey).split(" ");
        byte[] databytes = new byte[5];
        int leek = 0;
        for (String leekString : datas) {
            databytes[leek] = (byte) Integer.parseInt(leekString, 16);
            leek++;
        }

        linkedHashMap.put("data", encoder.encodeToString(databytes));

        MQTT mqtt = new MQTT();
        MqttConfig mqttconfig = new MqttConfig();
        mqttconfig.configure(mqtt);
        String newClientID = String.valueOf(Integer.parseInt(String.valueOf(mqtt.getClientId())) + clientIdOffset);
        mqtt.setClientId(newClientID);
        clientIdOffset++;
        int maxOffset = 100;
        if (clientIdOffset >= maxOffset) {
            clientIdOffset = 1;
        }

        /*
         * 优化：不断尝试发送，直到成功
         * */
        while (!isFinished) {
            BlockingConnection connection = mqtt.blockingConnection();
            try {
                connection.connect();
                connection.publish(sendTopic, JSONObject.toJSON(linkedHashMap).toString().getBytes(),
                        QoS.EXACTLY_ONCE, false);
                isFinished = true;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                connectionDelete(connection);
            }
        }
    }

    /**
     * 获取publish ack数据，byte[]型
     */
    private byte[] getAckData(JSONObject jsonObject) throws URISyntaxException {
        String ackTopic = "application/2/device/" +
                jsonObject.getString("deveui") +
                "/rx";
        Topic[] ackTopics = {new Topic(ackTopic, QoS.EXACTLY_ONCE)};
        Base64.Decoder decoder = Base64.getDecoder();
        boolean isFinished = false;

        MQTT mqtt = new MQTT();
        MqttConfig mqttconfig = new MqttConfig();
        mqttconfig.configure(mqtt);
        String newClientID = String.valueOf(Integer.parseInt(String.valueOf(mqtt.getClientId())) + clientIdOffset);
        mqtt.setClientId(newClientID);
        clientIdOffset++;
        int maxOffset = 100;
        if (clientIdOffset >= maxOffset) {
            clientIdOffset = 1;
        }

        int recycleTime = 1;
        while (!isFinished) {
            BlockingConnection connection = mqtt.blockingConnection();
            try {
                recycleTime++;
                if (recycleTime >= maxRecycleTime) {
                    isFinished = true;
                    return null;
                }
                connection.connect();
                connection.subscribe(ackTopics);
                /*
                 * 等待30秒接受ack校验包
                 * */
                Message message = connection.receive(30, TimeUnit.SECONDS);
                if (message == null) {
                    isFinished = true;
                    return null;
                } else {
                    JSONObject ackJsonObject = JSON.parseObject(message.getPayloadBuffer().toString().split("ascii: ")[1]);
                    if (decoder.decode(ackJsonObject.getString("data"))[0] == 0x03) {
                        isFinished = true;
                        return decoder.decode(ackJsonObject.getString("data"));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                connectionDelete(connection);
            }
        }
        return null;
    }

    /**
     * 获取publish 结果,Boolen 结果
     */
    private Boolean getAckResult(JSONObject jsonObject) throws URISyntaxException {
        String ackTopic = "application/2/device/" +
                jsonObject.getString("deveui") +
                "/ack";
        Topic[] ackTopics = {new Topic(ackTopic, QoS.EXACTLY_ONCE)};
        boolean isFinished = false;

        MQTT mqtt = new MQTT();
        MqttConfig mqttconfig = new MqttConfig();
        mqttconfig.configure(mqtt);
        String newClientID = String.valueOf(Integer.parseInt(String.valueOf(mqtt.getClientId())) + clientIdOffset);
        mqtt.setClientId(newClientID);
        clientIdOffset++;
        int maxOffset = 100;
        if (clientIdOffset >= maxOffset) {
            clientIdOffset = 1;
        }

        int recycleTime = 1;
        while (!isFinished) {
            BlockingConnection connection = mqtt.blockingConnection();
            try {
                recycleTime++;
                if (recycleTime >= maxOffset) {
                    isFinished = true;
                    return null;
                }
                connection.connect();
                connection.subscribe(ackTopics);
                /*
                 * 等待30秒接受ack校验包
                 * */
                Message message = connection.receive(30, TimeUnit.SECONDS);
                if (message == null) {
                    isFinished = true;
                    return null;
                } else {
                    JSONObject ackJsonObject = JSON.parseObject(message.getPayloadBuffer().toString().split("ascii: ")[1]);
                    isFinished = true;
                    return ackJsonObject.getBoolean("acknowledged");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                connectionDelete(connection);
            }
        }
        return null;
    }

    private void connectionDelete(BlockingConnection connection) {
        if (connection.isConnected()) {
            try {
                connection.disconnect();
                connection.kill();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
