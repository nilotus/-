package com.jit.sensor.util;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.jit.sensor.util.AnalysisNeedData;
import com.jit.sensor.util.MonthTime;
import com.jit.sensor.util.ThisTime;
import com.jit.sensor.entity.AverageInfo;
import com.jit.sensor.entity.Idtodate;
import com.jit.sensor.service.IdtoTimeService;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class MonthCustomizeDate {

    public static JSONObject getConversionDate(AverageInfo ag) {
        SimpleDateFormat df ;

        int biaozhi = 1;

        String deveui = ag.getDeveui();
        String devtype = ag.getDevtype();
        List<String> list1 = ag.getDatatype();
        String mainkey = deveui + "-" + devtype + "-";
        //创建格式化类nf
        NumberFormat nf = NumberFormat.getInstance();
        //数值2表示保留2位小数
        nf.setMaximumFractionDigits(2);


        IdtoTimeService idtoTimeService = AnalysisNeedData.getBean(IdtoTimeService.class);
        StringRedisTemplate strRedis = AnalysisNeedData.getBean(StringRedisTemplate.class);
        //时间进行初始化

        biaozhi = 0;
        df = new SimpleDateFormat("yyyy-MM");
        // df = getFormat();
        Long nowtime = Long.valueOf(ag.getNowtime());
        Long lasttime = Long.valueOf(ag.getLasttime());


        //需要的是来自哪个板子哪个传感器的感知信息
        String str = deveui + "-" + devtype + "-";

        Map<String, LinkedList<Double>> datamap = new HashMap<>();

        LinkedList<String> datelist = new LinkedList<>();

        for (long i = lasttime; i <= nowtime; ) {
            String zs = MonthTime.thisMonthEnd(String.valueOf(i));
            long lt = i;
            Date date = new Date(lt);
            String strdate = df.format(date);
            datelist.add(strdate.split(" ")[biaozhi]);
            SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                Date i1 = s.parse(zs);
                zs = String.valueOf(i1.getTime());
            } catch (ParseException e) {
                e.printStackTrace();
            }
            List<Idtodate> l = idtoTimeService.selectDayId
                    (zs, String.valueOf(i));
            int num = l.size();
            Map<String, Double> map1 = new HashMap<>();
            if(num == 0){
                for (String key1 : list1) {
                    map1.put(key1, 0.0);
                }

            }

            //  Map<String,Double> average = new HashMap<>();
            int wrongnum = 0;
            for (int j = 0; j < num; j++) {
                String key = str + l.get(j).getId();
                String s1 = strRedis.opsForValue().get(key);
                Map<String, Double> map;
                try {
                     map = JSONObject.parseObject(JSONObject.parseObject(s1).getString("value"), new TypeReference<Map<String, Double>>() {
                    });
                } catch (Exception e){
                    wrongnum++;
                    continue;
                }

                for (String key1 : list1) {
                    if (map1.get(key1) != null) {
                        map1.put(key1, Double.valueOf(map1.get(key1)) + Double.valueOf(map.get(key1)));
                    } else {
                        map1.put(key1, map.get(key1));
                    }
                }
            }

            num = num-wrongnum;
            if(num==0){
                for (String key1 : list1) {
                    map1.put(key1, 0.0);
                }
            }
            for (Map.Entry<String, Double> entry : map1.entrySet()) {
                LinkedList<Double> list2 = datamap.get(entry.getKey());
                if (list2 == null) {
                    list2 = new LinkedList<>();
                }
                try {
                    if(num != 0) {
                        list2.add(entry.getValue() / num);
                    } else {
                        list2.add(0.0);
                    }
                } catch (Exception e) {
                    list2.add(0.0);
                }

                datamap.put(entry.getKey(), list2);

            }
            try {
                i = df.parse(MonthTime.nextMonth(String.valueOf(i))).getTime();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }


        Map<String, LinkedList<String>> finaldata = new HashMap<>();

        for (Map.Entry<String, LinkedList<Double>> entry : datamap.entrySet()) {
            LinkedList<String> linkedList = new LinkedList<>();
            LinkedList<Double> linkedList1 = entry.getValue();
            for (Double aLinkedList1 : linkedList1) {
                linkedList.add(nf.format(aLinkedList1));
            }
            finaldata.put(entry.getKey(), linkedList);
        }
        Map<String, String> unit = new HashMap<>();
        for (String aList1 : list1) {
            unit.put(aList1, AnalysisNeedData.getDataUnit(mainkey + aList1));
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data", finaldata);
        jsonObject.put("time", datelist);
        jsonObject.put("unit", unit);

        return jsonObject;

    }

}



