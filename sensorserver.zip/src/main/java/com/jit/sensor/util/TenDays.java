package com.jit.sensor.util;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.jit.sensor.entity.AverageInfo;
import com.jit.sensor.entity.Idtodate;
import com.jit.sensor.service.IdtoTimeService;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class TenDays {
    public static JSONObject getConversionDate(AverageInfo ag) throws ParseException {
        String deveui = ag.getDeveui();
        String devtype = ag.getDevtype();
        List<String> list1 = ag.getDatatype();
        String mainkey = deveui + "-" + devtype + "-";
        //创建格式化类nf
        NumberFormat nf = NumberFormat.getInstance();
        //数值2表示保留2位小数
        nf.setMaximumFractionDigits(2);


        IdtoTimeService idtoTimeService = AnalysisNeedData.getBean(IdtoTimeService.class);
        StringRedisTemplate strRedis = AnalysisNeedData.getBean(StringRedisTemplate.class);
        //时间进行初始化

        SimpleDateFormat df;
        SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int biaozhi = 0;

        df = new SimpleDateFormat("yyyy-MM-dd");
        Long nowtime = Long.valueOf(ag.getNowtime());
        Long lasttime = Long.valueOf(ag.getLasttime());


        //需要的是来自哪个板子哪个传感器的感知信息
        String str = deveui + "-" + devtype + "-";

        Map<String, LinkedList<Double>> datamap = new HashMap<>();

        LinkedList<String> datelist = new LinkedList<>();


        for (long i = lasttime; i <= nowtime; ) {
            String zs;
            Long lt1;
            if (i < (lt1 = df2.parse(MonthTime.getShangXun(i)).getTime())) {
                zs = String.valueOf(lt1);
            } else if (i < (lt1 = df2.parse(MonthTime.getZhongXun(i)).getTime())) {
                zs = String.valueOf(lt1);
            } else {
                zs = String.valueOf(df2.parse(MonthTime.getXiaXun(i)).getTime());
            }

            long lt = new Long(zs);
            Date date = new Date(lt);
            String strdate = df.format(date);

            datelist.add(strdate.split(" ")[biaozhi]);

            System.out.println("当前运行到：" + ThisTime.zhuanzheng(i));

            List<Idtodate> l = idtoTimeService.selectDayId
                    (zs, String.valueOf(i));
            System.out.println("起始时间：" + ThisTime.zhuanzheng(Long.valueOf(String.valueOf(i))) + "-" + ThisTime.zhuanzheng(Long.valueOf(zs)));
            int num = l.size();
            System.out.println("每个时间段里需要的数据量：" + num);
            Map<String, Double> map1 = new HashMap<>();

            if (num == 0) {
                for (String key1 : list1) {
                    map1.put(key1, 0.0);
                }
            }

            int wrongnum = 0;
            for (int j = 0; j < num; j++) {
                String key = str + l.get(j).getId();
                String s1 = strRedis.opsForValue().get(key);
                Map<String, Double> map;
                try {
                    map = JSONObject.parseObject(JSONObject.parseObject(s1).getString("value"), new TypeReference<Map<String, Double>>() {
                    });
                } catch (Exception e) {
                    wrongnum++;
                    continue;
                }
                for (String key1 : list1) {
                    if (map1.get(key1) != null) {
                        map1.put(key1, map1.get(key1) + map.get(key1));
                    } else {
                        map1.put(key1, map.get(key1));
                    }
                }
            }

            num = num - wrongnum;
            System.out.println("存在的数据量：num：" + num);
            if (num == 0) {
                for (String key1 : list1) {
                    map1.put(key1, 0.0);
                }
            }

            for (Map.Entry<String, Double> entry : map1.entrySet()) {
                LinkedList<Double> list2 = datamap.get(entry.getKey());
                if (list2 == null) {
                    list2 = new LinkedList<>();
                }
                try {
                    if (num != 0) {
                        list2.add(entry.getValue() / num);
                    } else {
                        list2.add(0.0);
                    }
                } catch (Exception e) {
                    list2.add(0.0);
                }

                datamap.put(entry.getKey(), list2);

            }
            i = Long.parseLong(zs) + 1000;
        }


        Map<String, LinkedList<String>> finaldata = new HashMap<>();

        for (Map.Entry<String, LinkedList<Double>> entry : datamap.entrySet()) {
            LinkedList<String> linkedList = new LinkedList<>();
            LinkedList<Double> linkedList1 = entry.getValue();
            for (Double aLinkedList1 : linkedList1) {
                linkedList.add(nf.format(aLinkedList1));
            }
            finaldata.put(entry.getKey(), linkedList);
        }
        Map<String, String> unit = new HashMap<>();
        for (String aList1 : list1) {
            unit.put(aList1, AnalysisNeedData.getDataUnit(mainkey + aList1));
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data", finaldata);
        jsonObject.put("time", datelist);
        jsonObject.put("unit", unit);

        return jsonObject;
    }

}
