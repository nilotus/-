package com.jit.sensor.util;

import java.util.Calendar;
import java.util.Date;

/**
 * 描述:此类用于取得当前日期相对应的月初，月末，季初，季末，年初，年末，返回值均为String字符串
 * 1、得到当前日期         today()
 * 2、得到当前月份月初      thisMonth()
 * 3、得到当前月份月底      thisMonthEnd()
 * 4、得到当前季度季初      thisSeason()
 * 5、得到当前季度季末      thisSeasonEnd()
 * 6、得到当前年份年初      thisYear()
 * 7、得到当前年份年底      thisYearEnd()
 * 8、判断输入年份是否为闰年 leapYear
 * 注意事项:  日期格式为：xxxx-yy-zz (eg: 2007-12-05)
 * 实例:
 *
 * @author LOTA
 */
public class MonthTime {
//    private static int x;                  // 日期属性：年
//    private static int y;                  // 日期属性：月
//    private static int z;                  // 日期属性：日
    //  private static Calendar localTime;     // 当前日期

    public MonthTime(String l) {
        // SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
//            c.setTime(dateFormat.parse(l));
        //c.setTime(new Date(Long.valueOf(l)));

//        localTime = Calendar.getInstance();
//        localTime.setTime(new Date(Long.valueOf(l)));
//        System.out.println("取出设置后的localTime:"+localTime.getTime());
    }

    /**
     * 功能：得到当前日期 格式为：xxxx-yy-zz (eg: 2007-12-05)
     *
     * @return String
     * @author LOTA
     */
    public static String today(String l) {
        Calendar localTime = Calendar.getInstance();
        localTime.setTime(new Date(Long.valueOf(l)));

        String strY;
        String strZ;
        int x;                  // 日期属性：年
        int y;                  // 日期属性：月
        int z;                  // 日期属性：日
        x = localTime.get(Calendar.YEAR);
        y = localTime.get(Calendar.MONTH) + 1;
        z = localTime.get(Calendar.DATE);
        strY = y >= 10 ? String.valueOf(y) : ("0" + y);
        strZ = z >= 10 ? String.valueOf(z) : ("0" + z);
        return x + "-" + strY + "-" + strZ;
    }


    /**
     * 功能：得到当前月份月初 格式为：xxxx-yy-zz (eg: 2007-12-01) yjh:改，加完整的
     *
     * @return String
     * @author LOTA
     */
    public static String thisMonth(String l) {
        String strY;
        Calendar localTime = Calendar.getInstance();
        localTime.setTime(new Date(Long.valueOf(l)));
        int x;                  // 日期属性：年
        int y;                  // 日期属性：月
        int z;                  // 日期属性：日
        x = localTime.get(Calendar.YEAR);
        y = localTime.get(Calendar.MONTH) + 1;
        strY = y >= 10 ? String.valueOf(y) : ("0" + y);
        return x + "-" + strY + "-01" + " 00:00:01";
    }

    public static String lastthisMonth(String l) {
        Calendar localTime = Calendar.getInstance();
        localTime.setTime(new Date(Long.valueOf(l)));
        int x;                  // 日期属性：年
        int y;                  // 日期属性：月
        int z;                  // 日期属性：日
        String strY = null;
        x = localTime.get(Calendar.YEAR) - 1;
        y = localTime.get(Calendar.MONTH) + 1;
        strY = y >= 10 ? String.valueOf(y) : ("0" + y);
        return x + "-" + strY + "-01" + " 00:00:01";
    }

    public static String nextMonth(String l) {
        Calendar localTime = Calendar.getInstance();
        localTime.setTime(new Date(Long.valueOf(l)));
        int x;                  // 日期属性：年
        int y;                  // 日期属性：月
        int z;                  // 日期属性：日
        String strY = null;
        x = localTime.get(Calendar.YEAR);
        y = localTime.get(Calendar.MONTH) + 2;
        strY = y >= 10 ? String.valueOf(y) : ("0" + y);
        return x + "-" + strY + "-01" + " 00:00:01";
    }

    /**
     * 功能：得到当前月份月底 格式为：xxxx-yy-zz (eg: 2007-12-31) yjh:改，加完整的
     *
     * @return String
     * @author LOTA
     **/
    public static String thisMonthEnd(String l) {
        Calendar localTime = Calendar.getInstance();
        localTime.setTime(new Date(Long.valueOf(l)));
        int x;                  // 日期属性：年
        int y;                  // 日期属性：月
        int z;                  // 日期属性：日
        String strY = null;
        String strZ = null;
        boolean leap = false;
        x = localTime.get(Calendar.YEAR);
        y = localTime.get(Calendar.MONTH) + 1;
        if (y == 1 || y == 3 || y == 5 || y == 7 || y == 8 || y == 10 || y == 12) {
            strZ = "31";
        }
        if (y == 4 || y == 6 || y == 9 || y == 11) {
            strZ = "30";
        }
        if (y == 2) {
            leap = leapYear(x);
            if (leap) {
                strZ = "29";
            } else {
                strZ = "28";
            }
        }
        strY = y >= 10 ? String.valueOf(y) : ("0" + y);
        return x + "-" + strY + "-" + strZ + " 23:59:59";
    }

    /**
     * 功能：得到当前季度季初 格式为：xxxx-yy-zz (eg: 2007-10-01)<br>
     *
     * @return String
     * @author LOTA
     */
    public static String thisSeason(String l) {
        Calendar localTime = Calendar.getInstance();
        localTime.setTime(new Date(Long.valueOf(l)));
        int x;                  // 日期属性：年
        int y;                  // 日期属性：月
        int z;                  // 日期属性：日
        String dateString = "";
        x = localTime.get(Calendar.YEAR);
        y = localTime.get(Calendar.MONTH) + 1;
        if (y >= 1 && y <= 3) {
            dateString = x + "-" + "01" + "-" + "01";
        }
        if (y >= 4 && y <= 6) {
            dateString = x + "-" + "04" + "-" + "01";
        }
        if (y >= 7 && y <= 9) {
            dateString = x + "-" + "07" + "-" + "01";
        }
        if (y >= 10 && y <= 12) {
            dateString = x + "-" + "10" + "-" + "01";
        }
        return dateString;
    }

    /**
     * 功能：得到当前季度季末 格式为：xxxx-yy-zz (eg: 2007-12-31)<br>
     *
     * @return String
     * @author LOTA
     */
    public static String thisSeasonEnd(String l) {
        Calendar localTime = Calendar.getInstance();
        localTime.setTime(new Date(Long.valueOf(l)));
        int x;                  // 日期属性：年
        int y;                  // 日期属性：月
        int z;                  // 日期属性：日
        String dateString = "";
        x = localTime.get(Calendar.YEAR);
        y = localTime.get(Calendar.MONTH) + 1;
        if (y >= 1 && y <= 3) {
            dateString = x + "-" + "03" + "-" + "31";
        }
        if (y >= 4 && y <= 6) {
            dateString = x + "-" + "06" + "-" + "30";
        }
        if (y >= 7 && y <= 9) {
            dateString = x + "-" + "09" + "-" + "30";
        }
        if (y >= 10 && y <= 12) {
            dateString = x + "-" + "12" + "-" + "31";
        }
        return dateString;
    }

    /**
     * 功能：得到当前年份年初 格式为：xxxx-yy-zz (eg: 2007-01-01)<br>
     *
     * @return String
     * @author LOTA
     */
    public static String thisYear(String l) {
        Calendar localTime = Calendar.getInstance();
        localTime.setTime(new Date(Long.valueOf(l)));
        int x;                  // 日期属性：年
        int y;                  // 日期属性：月
        int z;                  // 日期属性：日
        x = localTime.get(Calendar.YEAR);
        return x + "-01" + "-01";
    }

    /**
     * 功能：得到当前年份年底 格式为：xxxx-yy-zz (eg: 2007-12-31)<br>
     *
     * @return String
     * @author LOTA
     */
    public static String thisYearEnd(String l) {
        Calendar localTime = Calendar.getInstance();
        localTime.setTime(new Date(Long.valueOf(l)));
        int x;                  // 日期属性：年
        int y;                  // 日期属性：月
        int z;                  // 日期属性：日
        x = localTime.get(Calendar.YEAR);
        return x + "-12" + "-31";
    }

    /**
     * 功能：判断输入年份是否为闰年<br>
     *
     * @param year
     * @return 是：true  否：false
     * @author LOTA
     */
    public static boolean leapYear(int year) {
        boolean leap;
        if (year % 4 == 0) {
            if (year % 100 == 0) {
                leap = year % 400 == 0;
            } else {
                leap = true;
            }
        } else {
            leap = false;
        }
        return leap;
    }

    //获取当月上旬（每月10号）
    public static String getShangXun(long i) {
        Calendar c = Calendar.getInstance();

        Calendar localTime1 = Calendar.getInstance();
        localTime1.setTime(new Date(i));
        int year, month;
        year = localTime1.get(Calendar.YEAR);
        month = localTime1.get(Calendar.MONTH) + 1;
        // return year+"-"+month+"-9 23:59:59";
        return year + "-" + month + "-10 00:00:00";
    }

    //获取当月中旬（每月20号）
    public static String getZhongXun(long i) {
        Calendar c = Calendar.getInstance();
        Calendar localTime1 = Calendar.getInstance();
        localTime1.setTime(new Date(i));
        int year, month;
        year = localTime1.get(Calendar.YEAR);
        month = localTime1.get(Calendar.MONTH) + 1;
        //   return year+"-"+month+"-19 23:59:59";
        return year + "-" + month + "-20 00:00:00";
    }

    //获取当月最后一天（）
    public static String getXiaXun(long i) {
        Calendar c = Calendar.getInstance();
        Calendar localTime1 = Calendar.getInstance();
        localTime1.setTime(new Date(i));
        String strY = null;
        String strZ = null;


        int x;                  // 日期属性：年
        int y;                  // 日期属性：月
        int z;                  // 日期属性：日


        boolean leap = false;
        x = localTime1.get(Calendar.YEAR);
        y = localTime1.get(Calendar.MONTH) + 1;
        if (y == 1 || y == 3 || y == 5 || y == 7 || y == 8 || y == 10 || y == 12) {
            strZ = "31";
        }
        if (y == 4 || y == 6 || y == 9 || y == 11) {
            strZ = "30";
        }
        if (y == 2) {
            leap = leapYear(x);
            if (leap) {
                strZ = "29";
            } else {
                strZ = "28";
            }
        }
        strY = y >= 10 ? String.valueOf(y) : ("0" + y);
        return x + "-" + strY + "-" + strZ + " 23:59:59";
    }


}