package com.jit.sensor.util;

import com.jit.sensor.entity.Sensorinfo;
import com.jit.sensor.service.SensorInfoService;

public class FindSensorInfo {
    public static  Sensorinfo find(String deveui,String devtype){
        SensorInfoService sensorInfoService =  AnalysisNeedData.getBean(SensorInfoService.class);
        return  sensorInfoService.selectByNeedData(deveui,devtype);
    }
}
