package com.jit.sensor.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ThisTime {
    public static Date HaveThisTime() {
        Date date = new Date();
        //设置日期格式
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateTime = df.format(date);
        Date date1 = null;
        try {
            date1 = df.parse(dateTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date1;
    }

    public static Date StringToDate(String date) {

        //设置日期格式
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date1 = null;
        try {
            date1 = df.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date1;
    }

    public static String stringToMySQLDateTimeString(Date date) {
        final String[] month = {
                "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
        };
        StringBuffer ret = new StringBuffer();
        //like "Sat Dec 17 15:55:16 CST 2005"
        String dateToString = date.toString();
        //append yyyy
        ret.append(dateToString.substring(24, 24 + 4));
        String sMonth = dateToString.substring(4, 4 + 3);
        //append mm
        for (int i = 0; i < 12; i++) {
            if (sMonth.equalsIgnoreCase(month[i])) {
                if ((i + 1) < 10) {
                    ret.append("-0");
                } else {
                    ret.append("-");
                }
                ret.append((i + 1));
                break;
            }
        }
        ret.append("-");
        ret.append(dateToString.substring(8, 8 + 2));
        ret.append(" ");
        ret.append(dateToString.substring(11, 11 + 8));
        return ret.toString();
    }

    public static int getNumberDay(Long l) {
        //设置日期格式
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String[] str = df.format(new Date(l)).split("-");
        Integer year = Integer.valueOf(str[0]);
        Integer month = Integer.valueOf(str[1]);
        Calendar c = Calendar.getInstance();
        //输入类型为int类型
        c.set(year, month, 0);
        return c.get(Calendar.DAY_OF_MONTH);
    }

    public static int getNumberDay() {
        //设置日期格式
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String[] str = df.format(date).split("-");
        int year = Integer.parseInt(str[0]);
        int month = Integer.parseInt(str[1]);
        Calendar c = Calendar.getInstance();
        //输入类型为int类型
        c.set(year, month, 0);
        return c.get(Calendar.DAY_OF_MONTH);
    }


    public static long lastonehour() {
        SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
        Integer i = Integer.valueOf(df.format(System.currentTimeMillis()).split(":")[0]);
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, i);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    public static String zhuanhour(Long l) {
        SimpleDateFormat df = new SimpleDateFormat("HH:mm");
        return df.format(new Date(l));
    }

    public static String zhuanzheng(Long l) {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return df.format(new Date(l));
    }

    public static String date2TimeStamp(String dateStr, String format) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            return String.valueOf(sdf.parse(dateStr).getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String getMonthEnd(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        try {
            calendar.setTime(dateFormat.parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return dateFormat.format(calendar.getTime());
    }

    public static Long getMonthChuo(String d) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = dateFormat.parse(d);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date != null ? date.getTime() : 0;
    }

}
