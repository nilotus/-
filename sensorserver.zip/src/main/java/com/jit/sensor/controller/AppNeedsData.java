package com.jit.sensor.controller;

import com.alibaba.fastjson.JSONObject;
import com.jit.sensor.entity.AppDataInfo;
import com.jit.sensor.entity.AverageInfo;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.global.tokenannotation.annotation.Authorization;
import com.jit.sensor.service.IdtoTimeService;
import com.jit.sensor.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/**
 * Android端相关接口
 *
 * @author LOTA
 */
@RestController
@RequestMapping("/AppNeeds")
public class AppNeedsData {
    @Autowired
    IdtoTimeService idtoTimeService;

    /**
     * 快速查询近一天、一周、一月、一年的数据
     */
    @Authorization
    @PostMapping("/LastTime")
    public TMessage getLastTimeDate(@RequestBody AppDataInfo a) {
        AverageInfo averageInfo;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //基本时间间隔为1小时
        Long jg = Long.valueOf("3600000");
        String type = a.getType();
        Long nowtime = ThisTime.lastonehour();
        Long lastime = Long.valueOf("999999999999");
        switch (type) {
            case "1":
                //一天
                lastime = nowtime - 86400000;
                break;
            case "2":
                //一周
                lastime = nowtime - 604800000;
                jg = jg * 24;
                break;
            case "3":
                //一月
                int num = ThisTime.getNumberDay(Long.valueOf("1530720000000"));
                jg = jg * 24;
                lastime = nowtime - Long.valueOf("86400000") * num;
                break;
            case "4":
                String monthym = MonthTime.thisMonthEnd(String.valueOf(nowtime));
                Date i = null;
                try {
                    i = simpleDateFormat.parse(monthym);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                String monthyc = MonthTime.lastthisMonth(String.valueOf(nowtime));
                Date i1 = null;
                try {
                    i1 = simpleDateFormat.parse(monthyc);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                averageInfo = inityear(String.valueOf(Objects.requireNonNull(i).getTime()),
                        String.valueOf(Objects.requireNonNull(i1).getTime()), a);
                JSONObject j = MonthCustomizeDate.getConversionDate(averageInfo);
                return ReturnUtil.finalObject(1, "获取成功", j);
            default:
                break;
        }
        averageInfo = init(nowtime, lastime, a);
        JSONObject j = ConversionDate.getConversionDate(jg, averageInfo);
        return ReturnUtil.finalObject(1, "获取成功", j);
    }

    /**
     * 初始化
     */
    private AverageInfo init(Long nowtime, Long lastime, AppDataInfo a) {
        AverageInfo averageInfo = new AverageInfo();

        averageInfo.setDevtype(a.getDevtype());
        averageInfo.setDeveui(a.getDeveui());
        averageInfo.setDatatype(a.getDatatype());
        averageInfo.setNowtime(String.valueOf(nowtime));
        averageInfo.setLasttime(String.valueOf(lastime));
        return averageInfo;
    }

    /**
     * 初始化
     */
    private AverageInfo inityear(String nowtime, String lastime, AppDataInfo a) {
        AverageInfo averageInfo = new AverageInfo();

        averageInfo.setDevtype(a.getDevtype());
        averageInfo.setDeveui(a.getDeveui());
        averageInfo.setDatatype(a.getDatatype());
        averageInfo.setNowtime(nowtime);
        averageInfo.setLasttime(lastime);
        return averageInfo;
    }

}
