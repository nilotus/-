package com.jit.sensor.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.jit.sensor.global.tokenannotation.annotation.Authorization;
import com.jit.sensor.global.tokenannotation.annotation.CurrentUser;
import com.jit.sensor.entity.Sensorinfo;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.entity.Universaldata;
import com.jit.sensor.entity.User;
import com.jit.sensor.service.SensorInfoService;
import com.jit.sensor.service.UniversalDataService;
import com.jit.sensor.util.FindSensorData;
import com.jit.sensor.util.ReturnUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/SensorInfo")
@Api(value = "/SensorInfo", tags = {"数据查询接口"})
public class SensorInfo {
    @Autowired
    SensorInfoService sensorInfoService;
    @Autowired
    UniversalDataService universalDataService;
    @Autowired
    StringRedisTemplate redis;

    /**
     * 获取最近一条数据
     * */
    @ApiOperation(value = "查询数据库中最新数据", notes = "通过参数查询对应传感器上传的最近的一条数据")
    @PostMapping(value = "SelectInfo",consumes = "application/json")
    @Authorization
    public TMessage selectInfo(@RequestBody Sensorinfo sensorinfo, @CurrentUser User user){

        String key1 = sensorinfo.getDeveui()+"-"+sensorinfo.getDevtype();
        String username = user.getUsername()+"-sensorprofile";
        JSONObject js =JSONObject.parseObject( redis.boundValueOps(username).get());
        if(js!=null){
            String str = js.getString (key1);
            if(!("1".equals(str))){
                 return ReturnUtil.finalObject(0, "没有权限查看", new JSONObject());
            }
        } else {
            return ReturnUtil.finalObject(0, "redis暂无该信息", new JSONObject());
        }

        String mainkey = sensorinfo.getDeveui()+"-"+sensorinfo.getDevtype()+"-";
        Map<String, String> map;
        String deveui = sensorinfo.getDeveui();
        String devtype = sensorinfo.getDevtype();
        map = FindSensorData.getSensorInfoMap(deveui, devtype);
        Universaldata universaldata;
        universaldata = universalDataService.SelectLastData(deveui, devtype);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String sd = sdf.format(new Date(Long.parseLong(universaldata.getTime()))); // 时间戳转换日期
        JSONObject retjson = new JSONObject();

       Map<String,Double> j = JSON.parseObject( FindSensorData.getAnalysisData(map, universaldata).toJSONString()
       ,new TypeReference<Map<String,Double>>(){});

       Map<String,String> unit = new HashMap<>();

       for(Map.Entry<String,Double> entry:j.entrySet()){
            String key = mainkey+entry.getKey();
            Map<String,Double> m = FindSensorData.getCfKey(key);
            for(Map.Entry<String,Double> entry1:m.entrySet()){
               j.put(entry.getKey(),entry.getValue()*entry1.getValue());
               unit.put(entry.getKey(),entry1.getKey());
            }
       }

        Map<String,String> finalmap = new HashMap<>();
        for(Map.Entry<String,Double> entry:j.entrySet()){
            finalmap.put(entry.getKey(), String.valueOf(entry.getValue()));
        }

        retjson.put("data", finalmap);
        retjson.put("time", sd);
        retjson.put("unit",unit);

        return ReturnUtil.finalObject(1, "获取最近一条数据", retjson);

    }
}
