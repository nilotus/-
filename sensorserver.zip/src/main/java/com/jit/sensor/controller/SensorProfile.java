package com.jit.sensor.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.jit.sensor.global.tokenannotation.annotation.CurrentUser;
import com.jit.sensor.util.AnalysisNeedData;
import com.jit.sensor.util.ReturnUtil;
import com.jit.sensor.entity.RelaybinduserKey;
import com.jit.sensor.entity.Sensorinfo;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.entity.User;
import com.jit.sensor.service.MqttService;
import com.jit.sensor.service.RelaybinduserService;
import com.jit.sensor.service.SensorInfoService;
import io.swagger.annotations.*;
import org.fusesource.mqtt.client.QoS;
import org.fusesource.mqtt.client.Topic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;
import com.jit.sensor.global.tokenannotation.annotation.Authorization;

import java.util.*;

@RestController
@RequestMapping("/sensor")
@Api(value = "/sensor",tags = {"配置操作接口"})
public class SensorProfile {
    private TMessage tMessage;
    @Autowired
    SensorInfoService sensorInfoService;
    @Autowired
    StringRedisTemplate redis;
    @Autowired
    RelaybinduserService relaybind;

    /**
     * 创建传感器配置
     * */
    @ApiOperation(value="传感器配置文件", notes="通过解析JSONObject转为对象插入数据库中")
    @PostMapping(value = "insertprofile")
    @Authorization
    public String insertProfile(@RequestBody Sensorinfo sensorinfo, @CurrentUser User user){

        if(sensorInfoService.selectByNeedData(sensorinfo.getDeveui(),sensorinfo.getDevtype())==null)
        {
                String username = user.getUsername();
                String key = sensorinfo.getDeveui()+"-"+sensorinfo.getDevtype();
                JSONObject j;
                j =JSONObject.parseObject( redis.boundValueOps(username+"-sensorprofile").get());
                if(j == null){
                    j = new JSONObject();
                }
                j.put(key,1);
                redis.boundValueOps(username+"-sensorprofile").set(j.toJSONString());
        } else {
            return setTMessage(0,"对应eui已存在该传感器配置",new JSONObject());
        }
        //板子控制权
        if (sensorInfoService.insert(sensorinfo)) {

            if(relaybind.selectByBindata(sensorinfo.getDeveui(),user.getUsername()) == null){
                RelaybinduserKey r = new RelaybinduserKey();
                r.setDeveui(sensorinfo.getDeveui());
                r.setPermission(1);
                r.setUserid(user.getUsername());
                relaybind.insert(r);
            }
        //redis和mqtt添加频道
          String topic =   redis.boundValueOps("mqtttopic").get();
            List<Topic>  topics = JSONObject.parseArray(topic,Topic.class);
            if(topics == null){
                topics = new ArrayList<>();
            }
            topics.add(new Topic(sensorinfo.getDeveui(), QoS.EXACTLY_ONCE));

            JSONObject j = new JSONObject();
            j.put("deveui",sensorinfo.getDeveui());

            MqttService m = AnalysisNeedData.getBean(MqttService.class);
            m.addSubscription(j);
            return setTMessage(1, "传感器配置文件插入成功", new JSONObject());
        } else {
            return setTMessage(0, "传感器配置文件插入失败", new JSONObject());
        }
    }

    /**
     * 获取传感器设备列表
     * */
    @GetMapping(value = "ListSensor")
    @Authorization
    public TMessage getListSensor(@CurrentUser User user){
       String str = redis.boundValueOps(user.getUsername()+"-sensorprofile").get();
        Map<String,Integer> map = JSONObject.parseObject(str,new TypeReference<Map<String,Integer>>(){});
        List<Sensorinfo> list = new ArrayList<>();
        for(Map.Entry<String,Integer> entry:map.entrySet()){
            String[] str2 = entry.getKey().split("-");
            Sensorinfo s = sensorInfoService.selectByNeedData(str2[0],str2[1]);
            list.add(s);
        }
        JSONObject js = new JSONObject();
        js.put("sensorlist",list);
        return  ReturnUtil.finalObject(1,"获取数据列表成功", js);
    }

    private String setTMessage(int i, String str, JSONObject json) {
        tMessage = new TMessage();
        tMessage.Code = i;
        tMessage.Message = str;
        tMessage.Time = String.valueOf(new Date());
        tMessage.Data = json;
        return JSON.toJSONString(tMessage);
    }
}
