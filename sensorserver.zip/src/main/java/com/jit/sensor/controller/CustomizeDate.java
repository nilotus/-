package com.jit.sensor.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.jit.sensor.entity.Customize;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.entity.Universaldata;
import com.jit.sensor.global.tokenannotation.annotation.Authorization;
import com.jit.sensor.service.UniversalDataService;
import com.jit.sensor.util.AnalysisNeedData;
import com.jit.sensor.util.FindSensorData;
import com.jit.sensor.util.ReturnUtil;
import com.jit.sensor.util.ThisTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.NumberFormat;
import java.util.*;

/**
 * @author LOTA
 */
@RestController
@RequestMapping("/CustomizeDate")
public class CustomizeDate {

    @Autowired
    UniversalDataService unservice;
    /**
     * 创建格式化类nf
     */
    private NumberFormat nf = NumberFormat.getInstance();

    /**
     * 安卓端获取以自定义时长为单位的近一小时数据
     */
    @PostMapping("/getInfo")
    @Authorization
    public TMessage getCustomizeInfo(@RequestBody Customize c) {
        long nowtime;
        long lasttime;
        long k = 60000;
        //数值2表示保留2位小数
        nf.setMaximumFractionDigits(2);
        LinkedList<String> datelist = new LinkedList<>();
        String deveui = c.getDeveui();
        String devtype = c.getDevtype();
        List<String> keys = c.getDatatype();
        String mainkey = deveui + "-" + devtype + "-";
        Map<String, String> map =
                FindSensorData.getSensorInfoMap(deveui, devtype);
        Map<String, LinkedList<Double>> finalmap = new HashMap<>();
        if (c.getType() == 1) {
            nowtime = System.currentTimeMillis();
            lasttime = nowtime - 3600000;
            k = k * c.getJiange();

            for (; lasttime <= nowtime; lasttime += k) {
                datelist.add(ThisTime.zhuanhour(lasttime));
                List<Universaldata> list = unservice.selectCusomizeData(
                        String.valueOf(lasttime + k), String.valueOf(lasttime), deveui, devtype);
                Map<String, Double> mapzj = new HashMap<>();
                if (list.size() == 0) {
                    for (String key : keys) {
                        mapzj.put(key, 0.0);
                    }
                }

                for (Universaldata aList : list) {
                    JSONObject jsonObject = FindSensorData.getAnalysisData(map, aList);
                    for (String key : keys) {
                        Double d = jsonObject.getDouble(key);
                        mapzj.merge(key, d, (a, b) -> a + b);
                    }
                }
                for (Map.Entry<String, Double> entry : mapzj.entrySet()) {
                    LinkedList<Double> valuelink = finalmap.get(entry.getKey());
                    if (valuelink == null) {
                        valuelink = new LinkedList<>();
                    }
                    try {
                        if (list.size() != 0) {
                            valuelink.add(findCf(mainkey + entry.getKey(), (entry.getValue() / list.size())));
                        } else {
                            valuelink.add(0.0);
                        }
                    } catch (Exception e) {
                        valuelink.add(0.0);
                    }
                    finalmap.put(entry.getKey(), valuelink);
                }
            }

            Map<String, String> unit = new HashMap<>();
            for (String key : keys) {
                unit.put(key, AnalysisNeedData.getDataUnit(mainkey + key));
            }

            LinkedList<String> datastr;
            Map<String, LinkedList<String>> cmap = new HashMap<>();

            for (Map.Entry<String, LinkedList<Double>> entry : finalmap.entrySet()) {
                datastr = new LinkedList<>();
                LinkedList<Double> list = entry.getValue();
                for (Double aList : list) {
                    datastr.add(nf.format(aList));
                }
                cmap.put(entry.getKey(), datastr);
            }

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("data", cmap);
            jsonObject.put("time", datelist);
            jsonObject.put("unit", unit);
            return ReturnUtil.finalObject(1, "获取成功", jsonObject);
        }
        return null;
    }

    private Double findCf(String key, Double d) {
        JSONObject jsonObject = FindSensorData.getCfData(key);
        Map<String, Map<String, Double>> it = JSON.parseObject(jsonObject.toJSONString(), new TypeReference<Map<String, Map<String, Double>>>() {
        });
        Map<String, Double> it1 = it.get(key);
        Double average = 0.0;
        if (it1 != null) {
            for (Map.Entry<String, Double> entry2 : it1.entrySet()) {
                average = d * entry2.getValue();
            }
        }
        return average;
    }

}
