package com.jit.sensor.controller;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.jit.sensor.entity.AverageInfo;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.entity.WebDataInfo;
import com.jit.sensor.service.IdtoTimeService;
import com.jit.sensor.util.ConversionDate;
import com.jit.sensor.util.MonthCustomizeDate;
import com.jit.sensor.util.MonthTime;
import com.jit.sensor.util.ReturnUtil;
import com.jit.sensor.util.ThisTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * WEB端相关接口
 */
@RestController
@RequestMapping("/WebNeeds")
public class WebNeedsData {

    @Autowired
    IdtoTimeService idtoTimeService;
    /**
     * List<AverageInfo> list ;
     */
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * web端获取最近一次数据
     */
    @PostMapping("/LastTime")
    public TMessage getLastTimeDate(@RequestBody WebDataInfo w) {
        List<AverageInfo> list;
        simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Long jg = w.getJg();
        String type = w.getType();
        Long nowtime = ThisTime.lastonehour();
        Long lastime = Long.valueOf("999999999999");
        switch (type) {
            case "1":
                lastime = nowtime - 86400000;
                break;
            case "2":
                lastime = nowtime - 604800000;
                break;
            case "3":
                int num = ThisTime.getNumberDay(Long.valueOf("1530720000000"));
                lastime = nowtime - Long.valueOf("86400000") * num;
                break;
            case "4":
                try {
                    lastime = simpleDateFormat.parse(MonthTime.lastthisMonth(String.valueOf(nowtime))).getTime();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                list = init(nowtime, lastime);
                JSONObject js = yearget(list);
                return ReturnUtil.finalObject(1, "获取成功", js);
            default:
                break;
        }

        list = init(nowtime, lastime);


        JSONObject unit = new JSONObject();
        JSONObject data = new JSONObject();
        LinkedList<String> time = null;
        for (AverageInfo aList : list) {
            JSONObject j = ConversionDate.getConversionDate(jg, aList);


            Map<String, String> map = JSONObject.parseObject(j.getJSONObject("unit").toString(), new TypeReference<Map<String, String>>() {
            });
            for (Map.Entry<String, String> entry : map.entrySet()) {
                unit.put(entry.getKey(), entry.getValue());
            }
            Map<String, LinkedList<String>> datamap = JSONObject.parseObject(j.getJSONObject("data").toString(), new TypeReference<Map<String, LinkedList<String>>>() {
            });
            for (Map.Entry<String, LinkedList<String>> entry : datamap.entrySet()) {
                data.put(entry.getKey(), entry.getValue());
            }
            if (time == null) {
                time = JSONObject.parseObject(j.getJSONArray("time").toJSONString(), new TypeReference<LinkedList<String>>() {
                });
            }
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data", data);
        jsonObject.put("time", time);
        jsonObject.put("unit", unit);
        return ReturnUtil.finalObject(1, "获取成功", jsonObject);

    }

    private List<AverageInfo> init(Long nowtime, Long lastime) {
        List<AverageInfo> list = new ArrayList<>();
        AverageInfo sensorinfo = new AverageInfo();
        sensorinfo.setDeveui("004a770066003289");
        sensorinfo.setDevtype("1");
        List<String> l = new ArrayList<>();
        l.add("Ammonia");
        l.add("Temperature");
        l.add("Humidity");
        sensorinfo.setDatatype(l);
        sensorinfo.setNowtime(String.valueOf(nowtime));
        sensorinfo.setLasttime(String.valueOf(lastime));
        list.add(sensorinfo);
        sensorinfo = new AverageInfo();
        sensorinfo.setDeveui("004a770066003289");
        sensorinfo.setDevtype("2");
        l = new ArrayList<>();
        l.add("windspeed");
        sensorinfo.setDatatype(l);
        sensorinfo.setNowtime(String.valueOf(nowtime));
        sensorinfo.setLasttime(String.valueOf(lastime));
        list.add(sensorinfo);
        return list;
    }


    private JSONObject yearget(List<AverageInfo> list) {

        JSONObject unit = new JSONObject();
        JSONObject data = new JSONObject();
        LinkedList<String> time = null;
        for (AverageInfo averageInfo : list) {
            String monthym = MonthTime.thisMonthEnd(averageInfo.getNowtime());
            try {
                Date i1 = simpleDateFormat.parse(monthym);
                averageInfo.setNowtime(String.valueOf(i1.getTime()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            String monthyc = MonthTime.thisMonth(averageInfo.getLasttime());
            try {
                Date i1 = simpleDateFormat.parse(monthyc);
                averageInfo.setLasttime(String.valueOf(i1.getTime()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            JSONObject j = MonthCustomizeDate.getConversionDate(averageInfo);
            Map<String, String> map = JSONObject.parseObject(j.getJSONObject("unit").toString(), new TypeReference<Map<String, String>>() {
            });
            for (Map.Entry<String, String> entry : map.entrySet()) {
                unit.put(entry.getKey(), entry.getValue());
            }
            Map<String, LinkedList<String>> datamap = JSONObject.parseObject(j.getJSONObject("data").toString(), new TypeReference<Map<String, LinkedList<String>>>() {
            });
            for (Map.Entry<String, LinkedList<String>> entry : datamap.entrySet()) {
                data.put(entry.getKey(), entry.getValue());
            }
            if (time == null) {
                time = JSONObject.parseObject(j.getJSONArray("time").toJSONString(), new TypeReference<LinkedList<String>>() {
                });
            }
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data", data);
        jsonObject.put("time", time);
        jsonObject.put("unit", unit);
        return jsonObject;

    }

}
