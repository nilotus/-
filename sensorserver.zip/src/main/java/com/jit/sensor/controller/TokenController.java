package com.jit.sensor.controller;

import com.alibaba.fastjson.JSONObject;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.entity.TokenModel;
import com.jit.sensor.entity.User;
import com.jit.sensor.global.tokenannotation.annotation.Authorization;
import com.jit.sensor.global.tokenannotation.manager.TokenManager;
import com.jit.sensor.service.UserService;
import com.jit.sensor.util.ReturnUtil;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tokens")
public class TokenController {
    @Autowired
    StringRedisTemplate redis;
    @Autowired
    private UserService userService;
    @Autowired
    private TokenManager tokenManager;

    /**
     * 用户登录
     */
    @PostMapping("/login")
    @ApiOperation(value = "登录")
    public TMessage login(@RequestBody User user1) {

        String username = user1.getUsername();
        String password = user1.getPassword();

        User user = userService.findByUsername(username);
        //未注册
        //密码错误
        if (user == null || !user.getPassword().equals(password)) {
            //提示用户名或密码错误
            return ReturnUtil.finalObject(0, "登录失败", new JSONObject());
        }
        TokenModel model = tokenManager.createToken(user.getId());
        return ReturnUtil.finalObject(1, "登录成功", (JSONObject) JSONObject.toJSON(model));
    }

    /**
     * 用户退出
     */
    @PostMapping("/delete")
    @Authorization
    public TMessage logout(@RequestBody User user) {
        tokenManager.deleteToken(user.getId());
        return ReturnUtil.finalObject(1, "退出成功", new JSONObject());
    }

    /**
     * 用户注册
     */
    @PostMapping("/insert")
    public TMessage insert(@RequestBody User user) {
        if (userService.findByUsername(user.getUsername()) != null) {
            return ReturnUtil.finalObject(0, "用户已存在", new JSONObject());
        } else {
            boolean i = userService.insert(user);
            if (i) {
                return ReturnUtil.finalObject(1, "用户注册成功", new JSONObject());
            }
        }
        return ReturnUtil.finalObject(0, "用户注册失败", new JSONObject());
    }

    /**
     * 用户修改密码
     */
    @PostMapping("/changepw")
    public TMessage changepassword(@RequestBody User user) {
        if (userService.updateByUserName(user)) {
            int id = userService.findByUsername(user.getUsername()).getId();
            tokenManager.deleteToken(id);
            return ReturnUtil.finalObject(1, "用户修改密码成功", new JSONObject());
        }
        return ReturnUtil.finalObject(0, "用户修改密码失败", new JSONObject());
    }


}
