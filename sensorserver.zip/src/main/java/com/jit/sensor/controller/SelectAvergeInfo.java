package com.jit.sensor.controller;

import com.alibaba.fastjson.JSONObject;
import com.jit.sensor.entity.AverageInfo;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.service.IdtoTimeService;
import com.jit.sensor.util.ConversionDate;
import com.jit.sensor.util.MonthCustomizeDate;
import com.jit.sensor.util.TenDays;
import com.jit.sensor.util.MonthTime;
import com.jit.sensor.util.ReturnUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisKeyValueTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/SelectAverageInfo")
public class SelectAvergeInfo {

    @Autowired
    IdtoTimeService idtoTimeService;
    @Autowired
    private StringRedisTemplate strRedis;

    /**
     * 获取自定义时间范围内的数据
     */
    @PostMapping("selectInfo")
    public TMessage selectInfo(@RequestBody AverageInfo averageInfo) throws ParseException {
        long nowtime = Long.valueOf(averageInfo.getNowtime());
        long lasttime = Long.valueOf(averageInfo.getLasttime());
        long interval = nowtime - lasttime;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        //间隔时间为1秒
        long jiange = 1000;
        //小于1天
        if (interval <= 86400000) {
            //间隔时间为小时
            jiange = jiange * 60 * 60;
        }
        //小于1.3个月，按40天来算
        else if (interval <= Long.valueOf("3456000000")) {
            //间隔时间为天
            jiange = jiange * 60 * 60 * 24;
        }
        //小于6个月
        else if (interval <= Long.valueOf("15552000000")) {
            //间隔时间为旬
            return ReturnUtil.finalObject(1, "获取数据成功", TenDays.getConversionDate(averageInfo));
        } else {
            //间隔时间为月(注意大月和小月)
            String monthym = MonthTime.thisMonthEnd(averageInfo.getNowtime());
            try {
                Date i = simpleDateFormat.parse(monthym);
                averageInfo.setNowtime(String.valueOf(i.getTime()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            String monthyc = MonthTime.thisMonth(averageInfo.getLasttime());
            try {
                Date i = simpleDateFormat.parse(monthyc);
                averageInfo.setLasttime(String.valueOf(i.getTime()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            JSONObject j = MonthCustomizeDate.getConversionDate(averageInfo);
            return ReturnUtil.finalObject(1, "获取成功", j);
        }
        JSONObject j = ConversionDate.getConversionDate(jiange, averageInfo);
        return ReturnUtil.finalObject(1, "获取成功", j);
    }

}
