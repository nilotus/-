package com.jit.sensor.controller;


import com.alibaba.fastjson.JSONObject;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.entity.User;
import com.jit.sensor.global.tokenannotation.annotation.Authorization;
import com.jit.sensor.global.tokenannotation.annotation.CurrentUser;
import com.jit.sensor.service.MqttService;
import com.jit.sensor.util.ReturnUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.*;

/**
 * Mqtt协议接口
 *
 * @author LOTA
 * @see MqttService 业务逻辑实现类
 */
@RestController
@RequestMapping("/mqtt")
public class MqttController {
    private final
    StringRedisTemplate redis;
    private final MqttService mqttService;

    @Autowired
    public MqttController(StringRedisTemplate redis, MqttService mqttService) {
        this.redis = redis;
        this.mqttService = mqttService;
    }

    /**
     * 从Redis获取当前继电器状态
     * @return {@code TMessage}
     */
    @GetMapping("/Redishuoqu")
    public TMessage getRedisSensorStatus() {
        String str = "004a770066003289" + "-3-";
        StringBuilder switchStringBuilder = new StringBuilder();
        int relayNum = 7;
        for (int i = relayNum; i >= 0; i--) {
            switchStringBuilder.append(redis.boundValueOps(str + i).get());
        }
        String switchString = switchStringBuilder.toString();
        JSONObject js = new JSONObject();
        js.put("switchString", switchString);
        return ReturnUtil.finalObject(1, "redis读取成功", js);
    }



    /**
     * 设置传感器上传周期
     * 返回值仅仅表示设置的请求发送成功,不表示设置成功
     */
    @PostMapping("/uploadcycle")
    @Authorization
    public TMessage updateSensorCycle(@RequestBody JSONObject jsonObject, @CurrentUser User user) throws Exception {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    TMessage tMessage;
                    JSONObject jsonObject1 = jsonObject;
                    int i = 0;
                    do {
                        i++;
                        tMessage = mqttService.updateSensorCycle(jsonObject1);
                    } while (tMessage.Code != 1 && i < 3);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
        return ReturnUtil.finalObject(1, "设置板子上传频率提交成功", new JSONObject());


    }

    /**
     * 获取继电器八路状态
     */
    @GetMapping("/huoqu")
    public TMessage getSensorStatus() {
        try {
            return mqttService.getRelayStatus();
        } catch (Exception e) {
            e.printStackTrace();
            return ReturnUtil.finalObject(0, "获取失败", new JSONObject());
        }
    }

    /**
     * 设置继电器状态
     */
    @Authorization
    @PostMapping("/shezhi")
    public TMessage setSensorStatus(@RequestBody JSONObject jsonObject, @CurrentUser User user) throws Exception {
        return mqttService.setRelayStatus(jsonObject, user);
    }


}