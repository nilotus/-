package com.jit.sensor.global;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jit.sensor.global.socket.MyWebsocket;
import com.jit.sensor.util.AnalysisNeedData;

import com.jit.sensor.entity.RelaybinduserKey;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.entity.Universaldata;
import com.jit.sensor.service.MqttService;
import com.jit.sensor.service.RelaybinduserService;
import com.jit.sensor.service.SensorInfoService;
import com.jit.sensor.service.UniversalDataService;

import org.fusesource.hawtbuf.Buffer;
import org.fusesource.hawtbuf.UTF8Buffer;
import org.fusesource.hawtdispatch.Dispatch;
import org.fusesource.mqtt.client.*;
import org.fusesource.mqtt.codec.MQTTFrame;
import org.springframework.context.ApplicationContext;

import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;

import static com.jit.sensor.util.CRC.CRCcheck;


public class MqttClient {
    public static MQTT mqtt;
    public static CallbackConnection callbackConnection;
    public static Topic[] topics;
    private static ApplicationContext applicationContext;

    private UniversalDataService universalDataService;
    private SensorInfoService sensorInfoService;
    private MqttSet mqttSet;
    private Boolean isConnected;

    public MqttClient(ApplicationContext context) {
        applicationContext = context;
        mqttSet = getMqttSet();
        universalDataService = getUniversalDataService();
        sensorInfoService = AnalysisNeedData.getBean(SensorInfoService.class);
    }

    public static MqttSet getMqttSet() {
        return applicationContext.getBean(MqttSet.class);
    }

    /**
     * 启动类set入，调用下面set方法
     */
    public CallbackConnection init() {
        try {
            mqttSet.builder();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mqtt = mqttSet.getMqtt();
        // 选择消息分发队列
        mqtt.setDispatchQueue(Dispatch.createQueue("fol"));
        // 若没有调用方法setDispatchQueue，客户端将为连接新建一个队列。如果想实现多个连接使用公用的队列，显式地指定队列是一个非常方便的实现方法

        // 设置跟踪器
        mqtt.setTracer(new Tracer() {
            @Override
            public void onReceive(MQTTFrame frame) {
            }

            @Override
            public void onSend(MQTTFrame frame) {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void debug(String message, Object... args) {
            }
        });
//           使用回调式API
        callbackConnection = mqtt
                .callbackConnection();
         /*
         * 连接监听器
         * Listener为过时方法
         * */
        callbackConnection.listener(new Listener() {
            // 接收订阅话题发布的消息
            @Override
            public void onPublish(UTF8Buffer topic, Buffer payload,
                                  Runnable onComplete) {

                //获取数据
                JSONObject jsonObject = JSON.parseObject(new String(payload.toByteArray()));

                String data1;
                data1 = jsonObject.getString("data");

                Decoder decoder = Base64.getDecoder();
                if (data1 != null) {
                    byte[] decode = decoder.decode(data1);
                    try {
                        if (decode[0] != 0 && CRCcheck(decode)) {
                            Universaldata universaldata = new Universaldata();
                            universaldata.setDeveui(jsonObject.getString("devEUI"));


                            universaldata.setDevtype(String.valueOf(decode[0]));

                            if (sensorInfoService.selectByNeedData(jsonObject.getString("devEUI"), String.valueOf(decode[0]))
                                    != null) {
                                universaldata.setData(data1);
                                universaldata.setTime(String.valueOf(System.currentTimeMillis()));
                                try {
                                    TMessage tm = null;
                                    try {
                                        tm = AnalysisNeedData.getWebSocketData(universaldata);
                                        tm.Code = (int) decode[0];
                                    } catch (Exception ignored) {
                                    }
                                    if (tm != null) {
                                        try {
                                            MyWebsocket.sendMessage(JSONObject.toJSONString(tm));
                                        } catch (Exception e){
                                         e.printStackTrace();
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
//                                if (universalDataService.insertdata(universaldata)) {
//                                } else {
//                                }
                            }
                        }


                    } catch (Exception ignored){
                    }
                }
                onComplete.run();
            }

            // 连接失败
            @Override
            public void onFailure(Throwable value) {
                callbackConnection.disconnect(null);
                isConnected = false;
                for (int num = 0; (num < 3) && !isConnected; num++) {
                    callbackConnection.connect(new Callback<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            isConnected = true;
                        }

                        @Override
                        public void onFailure(Throwable throwable) {
                        }
                    });
                }
            }

            // 连接断开
            @Override
            public void onDisconnected() {
            }

            // 连接成功
            @Override
            public void onConnected() {
            }
        });

//        建立连接
        callbackConnection.connect(new Callback<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
            }

            @Override
            public void onFailure(Throwable throwable) {
            }
        });

        return callbackConnection;
    }


    private UniversalDataService getUniversalDataService() {
        return applicationContext.getBean(UniversalDataService.class);
    }


    public void inittopics() {
        RelaybinduserService relaybind = AnalysisNeedData.getBean(RelaybinduserService.class);
        MqttService mqtt = AnalysisNeedData.getBean(MqttService.class);
        List<RelaybinduserKey> list = relaybind.selectall();
        JSONObject j = new JSONObject();
        for (RelaybinduserKey aList : list) {
            j.put("deveui", aList.getDeveui());
            mqtt.addSubscription(j);
        }
    }

}
