package com.jit.sensor.global;

import com.alibaba.fastjson.JSONObject;
import com.jit.sensor.util.AnalysisNeedData;
import com.jit.sensor.util.FindSensorData;
import com.jit.sensor.util.ThisTime;
import com.jit.sensor.entity.Universaldata;
import com.jit.sensor.service.UniversalDataService;

import org.springframework.data.redis.core.StringRedisTemplate;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;


import static com.alibaba.fastjson.util.IOUtils.close;


public class ceshi {
    private static final SimpleDateFormat DF = new SimpleDateFormat("HH:mm:ss");

    private StringRedisTemplate redis;
    static long nowtime = Long.valueOf("1511452800000");

    public void reportTime() {
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        redis = AnalysisNeedData.getBean(StringRedisTemplate.class);
        Long lasttime = Long.valueOf("1508774400000");
        UniversalDataService universalDataService = AnalysisNeedData.getBean(UniversalDataService.class);
        LinkedList<String> date = new LinkedList<>();
        LinkedList<Double> data = new LinkedList<>();
        for (; lasttime < nowtime; lasttime += 3600000) {
            List<Universaldata> list = universalDataService.SelectIntervalData(String.valueOf(nowtime), String.valueOf(lasttime));
            for (int i = 1; i <= list.size(); i++) {
                Universaldata universaldata = list.get(i - 1);
                if("1".equals(universaldata.getDevtype())) {
                    continue;
                }
                Map<String, String> map = FindSensorData.getSensorInfoMap(universaldata.getDeveui(), universaldata.getDevtype());
                JSONObject jsonObject = FindSensorData.getAnalysisData(map, universaldata);
                date.add(ThisTime.zhuanhour(Long.valueOf(universaldata.getTime())));
                data.add(Double.valueOf(jsonObject.getDouble("windspeed"))*0.01);
            }
        }
         redis.boundValueOps("date").set(JSONObject.toJSONString(date));
            redis.boundValueOps("data").set(JSONObject.toJSONString(data));
    }


    public static byte[] serializeList(List<?> list) {
        if (list == null || list.size() == 0) {
            return null;
        }
        ObjectOutputStream oos = null;
        ByteArrayOutputStream baos = null;
        byte[] bytes = null;
        try {
            baos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(baos);
            for (Object obj : list) {
                oos.writeObject(obj);
            }
            bytes = baos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(oos);
            close(baos);
        }
        return bytes;
    }

    class qiuzhi {
        public int getInfonum() {
            return infonum;
        }

        public void setInfonum(int infonum) {
            this.infonum = infonum;
        }

        public Double getInfosum() {
            return infosum;
        }

        public void setInfosum(Double infosum) {
            this.infosum = infosum;
        }

        int infonum;
        Double infosum;
    }
}
