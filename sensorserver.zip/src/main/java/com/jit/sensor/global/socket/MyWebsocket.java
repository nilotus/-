package com.jit.sensor.global.socket;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jit.sensor.global.tokenannotation.manager.TokenManager;
import com.jit.sensor.entity.TokenModel;
import com.jit.sensor.util.AnalysisNeedData;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.entity.User;
import com.jit.sensor.service.MqttService;
import com.jit.sensor.service.UserService;
import com.jit.sensor.util.ThisTime;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.Date;

@ServerEndpoint(value = "/websocket/{token}")
@Component
public class MyWebsocket {
    private static Session session = null;
    private User user;
    MqttService mqttService;

    /**
     * 连接建立成功调用的方法
     */
    @OnOpen
    public void onOpen(@PathParam("token") String token, Session session) throws IOException {
        System.out.println("连接成功:"+ ThisTime.zhuanzheng(System.currentTimeMillis()));
        System.out.println("string token:"+token);
        MyWebsocket.session = session;
        MessageTransfer.setSession(session);
        mqttService = AnalysisNeedData.getBean(MqttService.class);
        TokenManager manager = AnalysisNeedData.getBean(TokenManager.class);
        UserService userService = AnalysisNeedData.getBean(UserService.class);
        TokenModel model = manager.getToken(token);
        System.out.println("TokenModel:"+JSONObject.toJSONString(model));
        if (manager.checkToken(model)) {
            String str = token.split("_")[0];
            user = userService.findById(Integer.parseInt(str));
            System.out.println("websocket登录成功");
        } else {
            System.out.println("websocket验证失败");
        }
    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {
        System.out.println("有一连接关闭");
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     */
    @OnMessage
    public void onMessage(String message, Session session) throws Exception {
        System.out.println("来自客户端的消息:" + message);
        JSONObject jsonObject = JSON.parseObject(message);
        String type = jsonObject.getString("type");
        TMessage tm;
        switch (type) {
            case "1":
                tm = mqttService.updateSensorCycle(jsonObject);
                if(tm.Code!=0) {
                    tm.Code = 99;
                }
                break;
            case "2":
                tm = mqttService.getRelayStatus();
                if(tm.Code!=0) {
                    tm.Code = 3;
                }
                break;
            case "3":
                tm = mqttService.setRelayStatus(jsonObject,user);
                if(tm.Code!=0) {
                    tm.Code = 99;
                }
                break;
            default:
                tm = new TMessage();
                JSONObject js = new JSONObject();
                js.put("time",new Date().toString());
                tm.Data = js;
                tm.Code = -1;
                break;
        }
        System.out.println("mywebsocket 66:" + JSONObject.toJSONString(tm));
        session.getBasicRemote().sendText(JSONObject.toJSONString(tm));

    }

    /**
     * 发生错误时调用
     */
    @OnError
    public void onError(Session session, Throwable error) {
        System.out.println("连接断开:"+ ThisTime.zhuanzheng(System.currentTimeMillis()));
        System.out.println("Mywebsocket发生错误");
        error.printStackTrace();
    }

    public static void sendMessage(String message)  {
        System.out.println("websocket准备发送");
        try {
            if(session == null){
                System.out.println("session为空");
            }
            if (session != null &&session.isOpen()) {
                session.getBasicRemote().sendText(message);
                System.out.println("发送成功");
            }
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("session出错 123");
        }
        System.out.println("websocketv发送结束");
    }
}