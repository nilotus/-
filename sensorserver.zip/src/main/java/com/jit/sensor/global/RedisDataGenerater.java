package com.jit.sensor.global;

import com.alibaba.fastjson.JSONObject;
import redis.clients.jedis.Jedis;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class RedisDataGenerater {
    public static void main(String[] args) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-M-d H:m:s");
        Jedis jedis = new Jedis("localhost", 6379);
        jedis.select(3);
        LinkedList<String> dateList = new LinkedList<>();
        LinkedList<Integer> dataList = new LinkedList<>();
        int listsize = 10 * 10000;
        Calendar calendar = Calendar.getInstance();
        Date date = dateFormat.parse("2018-1-1 00:00:00");
        calendar.setTime(date);
        Random random = new Random();
        for (int i = 0; i < listsize; i++) {
            dateList.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar.getTime()));
            calendar.add(Calendar.SECOND, 20);
            dataList.add(random.nextInt(30));
        }

        jedis.set("date", JSONObject.toJSONString(dateList));
        jedis.set("data", JSONObject.toJSONString(dataList));
        jedis.disconnect();
    }
}
