package com.jit.sensor;




import org.mybatis.generator.api.MyBatisGenerator;
import org.mybatis.generator.config.Configuration;
import org.mybatis.generator.config.xml.ConfigurationParser;
import org.mybatis.generator.exception.InvalidConfigurationException;
import org.mybatis.generator.exception.XMLParserException;
import org.mybatis.generator.internal.DefaultShellCallback;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class MybatisGenerator {
    public void generator() {

        List<String> warnings = new ArrayList<String>();
        boolean overwrite = true;
        //指定 逆向工程配置文件
        File configFile = new File("C:/Users/11599/workspace/sensorserver/src/main/resources/generator.xml");
        ConfigurationParser cp = new ConfigurationParser(warnings);

        Configuration config;
        try {
            config = cp.parseConfiguration(configFile);
            DefaultShellCallback callback = new DefaultShellCallback(overwrite);
            MyBatisGenerator myBatisGenerator = new MyBatisGenerator(config,
                    callback, warnings);
            myBatisGenerator.generate(null);
        } catch (IOException | XMLParserException | InvalidConfigurationException | SQLException | InterruptedException e) {
            e.printStackTrace();
        }


    }
    public static void main(String[] args)  {
        try {
            MybatisGenerator mybatisGeneratorSqlmap = new MybatisGenerator();
            mybatisGeneratorSqlmap.generator();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
