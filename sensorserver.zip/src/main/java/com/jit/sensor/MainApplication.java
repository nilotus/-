package com.jit.sensor;


import com.alibaba.fastjson.JSONObject;
import com.jit.sensor.global.MqttClient;
import com.jit.sensor.util.AnalysisNeedData;
import com.jit.sensor.entity.TMessage;
import com.jit.sensor.service.MqttService;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@MapperScan("com.jit.sensor.mapper")
@SpringBootApplication
@EnableScheduling
@EnableSwagger2
public class MainApplication {
    public static MqttClient mqttClient;

    public static void main(String args[]) throws Exception {
        ConfigurableApplicationContext applicationContext = SpringApplication.run(MainApplication.class, args);

        new AnalysisNeedData().setApplicationContext(applicationContext);
        mqttClient = new MqttClient(applicationContext);
        mqttClient.init();
        mqttClient.inittopics();

        new Thread(new Runnable() {
            @Override
            public void run() {
                MqttService mqttService = AnalysisNeedData.getBean(MqttService.class);
                TMessage tm = null;
                int i = 0;
                do {
                    i++;
                    try {
                        Thread.sleep(6000);
                        tm = mqttService.getRelayStatus();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                } while (tm.Code != 1 && i < 3);
                StringRedisTemplate redis = AnalysisNeedData.getBean(StringRedisTemplate.class);
                String str = JSONObject.parseObject(String.valueOf(tm.Data)).getString("switchString");
                if (str != null) {
                    char[] s = str.toCharArray();
                    for (int j = 7; j >= 0; j--) {
                        redis.boundValueOps("004a770066003289" + "-3-" + j).set(String.valueOf(s[j]));
                    }
                } else {
                    System.out.println("启动更新开关状态成功");

                }
            }
        }).start();

    }
}
