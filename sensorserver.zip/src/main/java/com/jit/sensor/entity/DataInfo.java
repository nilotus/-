package com.jit.sensor.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;

/**
 * @deprecated
 * */
@Entity
@Getter
@Setter
public class DataInfo {
    String time;
    Double data;
}
