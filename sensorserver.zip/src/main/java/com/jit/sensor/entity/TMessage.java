package com.jit.sensor.entity;

public class TMessage {
    public Integer Code;
    public String Message;
    public String Time;
    public Object Data;


}
