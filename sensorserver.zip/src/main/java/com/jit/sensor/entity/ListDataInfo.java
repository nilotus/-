package com.jit.sensor.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import javax.persistence.Entity;

@Entity
@Setter
@Getter
public class ListDataInfo  {
    @Id
   String  list ;

}
