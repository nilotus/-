package com.jit.sensor.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
/**
 * Android端获取近一小时数据时指定间隔实体类
 * */
@Getter
@Setter
public class Customize {
    String deveui;
    String devtype;
    List<String> datatype;
    int type;
    int jiange;
}
