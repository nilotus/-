package com.jit.sensor.entity;


import lombok.Data;

import java.util.List;

/**
 * 自定义时间实体类
 * */
@Data
public class AverageInfo {
    String deveui;
    String devtype;
    List<String> datatype;
    String nowtime;
    String lasttime;

}
