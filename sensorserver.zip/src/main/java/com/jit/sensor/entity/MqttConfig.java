package com.jit.sensor.entity;

import org.fusesource.mqtt.client.QoS;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import static org.fusesource.mqtt.client.QoS.AT_LEAST_ONCE;


@lombok.Setter
@lombok.Getter
@Configuration
@PropertySource("classpath:/config/mqtt.properties")
@ConfigurationProperties(prefix = "mqtt", ignoreInvalidFields = false)
@Component
public class MqttConfig {


    public String host;
    public String clientId;
    public Boolean cleanSession;
    public short keepalive;
    public String userName;
    public String password;
    public String willTopic;
    public String willmessage;
    public QoS willqos = AT_LEAST_ONCE;
    public Boolean WillRetain;
    public String version;
    public long connectattemptsmax;
    public long reconnectattemptsmax;
    public long reconnectdelay;
    public long reconnectDelaymax;
    public int reconnectbackOffmultiplie;
    public int receivebuffersize;
    public int sendbuffersize;
    public int trafficclass;
    public int maxreadrate;
    public int maxwriterate;
}
