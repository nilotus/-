package com.jit.sensor.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
* Android 用于快速查询的实体类
* */
@Getter
@Setter
public class AppDataInfo {
    String type;
    String deveui;
    String devtype;
    List<String> datatype;
}
