package com.jit.sensor.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WebDataInfo {
    String type;
    Long jg;
}
